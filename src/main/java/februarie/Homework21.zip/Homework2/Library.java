package main.java.februarie.Homework2;

public class Library {

    public static void main(String[] args) {


        Album album1 = new Album( "First Album", 365, "best");
        album1.addNewBook();
        System.out.println(album1.bookName + " has " + album1.totalPage + " pages and the photo quality is " + album1.pictureQuality);
        System.out.println(" ");

        Novel novel1 = new NovelBuilder().createNovel();
        novel1.addNewBook();
        System.out.println(novel1.bookName + " has " + novel1.totalPage + " pages and is a " + novel1.bookType + " book for kids older then  "+ novel1.ageRating);
        System.out.println(" ");

        Novel novel2 = new NovelBuilder().createNovel();
        novel2.addNewBook();
        System.out.println(novel2.bookName + " has " + novel2.totalPage + " pages and is a " + novel2.bookType + " book for kids older then  "+ novel2.ageRating);
        System.out.println(" ");


    }
}
