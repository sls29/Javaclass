package main.java.februarie.Homework2;

public class Album extends Book{
    String bookName;
    int totalPage;
    String pictureQuality;

    public Album(String bookName, int totalPage, String pictureQuality) {
        this.bookName = bookName;
        this.totalPage = totalPage;
        this.pictureQuality = pictureQuality;
    }

    @Override
    public void addNewBook() {
        Album album1 = new Album( "First Album", 365, "best");
        System.out.println( "A new album has been added");
    }
}
