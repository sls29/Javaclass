package main.java.februarie.Homework2;

public class Book {
    String bookName;
    int totalPage;

    public Book(String bookName, int totalPage) {
        this.bookName = bookName;
        this.totalPage = totalPage;
    }

    public Book() {
    }

    public void addNewBook(){
        System.out.println("A new book has been added");
    }
}
