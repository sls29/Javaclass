package main.java.februarie.Homework2;

public class NovelBuilder {
    public Novel createNovel() {
        return new Novel();
    }
}