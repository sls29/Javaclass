package main.java.februarie.Homework2;

public abstract class Novel extends Book {

    String bookName;
    int totalPage;
    String bookType;
    int ageRating;


     public Novel(String bookName, int totalPage, String bookType, int ageRating) {
        this.bookName = bookName;
        this.totalPage = totalPage;
        this.bookType = bookType;
        this.ageRating = ageRating;
    }

    @Override
    public void addNewBook() {

        System.out.println("A new novel has been added");
    }
}
